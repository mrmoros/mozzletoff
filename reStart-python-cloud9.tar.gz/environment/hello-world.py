import random

# DISPLAY what is required
print("Welcome to Guess the Number!")
print("The rules are simple. I will think of a number, and you will try to guess it.")

#GENERATE a random number
number = random.randint(1,10)


# SET IF gues is right to false
isGuessRight = False

# CREATE WHILE LOOP until vorrect guess
while isGuessRight != True:
    # REQUEST another guess until correct
    guess = input("Guess a number between 1 and 10: ")
    # CONDITIONAL IF/ELSE until true loop
    if int(guess) == number:
        print("You guessed {}. That is correct! You win!".format(guess))
        isGuessRight = True
    # ITERATE LOOP until correct
    else:
        print("You guessed {}. Sorry, that isn’t it. Try again.".format(guess))
        